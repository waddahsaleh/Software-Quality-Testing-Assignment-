import java.util.Scanner;

public class NextDate {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        // Ask for input
        System.out.print("Enter the day (1-31): ");
        int day = input.nextInt();

        System.out.print("Enter the month (1-12): ");
        int month = input.nextInt();

        System.out.print("Enter the year (1812-2212): ");
        int year = input.nextInt();

        // Call nextDate function and print output
        String nextDate = nextDate(day, month, year);
        System.out.println("Next date: " + nextDate);

        input.close();
    }

    public static String nextDate(int day, int month, int year) {
        // Check for valid input dates
        if (year < 1812 || year > 2212) {
            return "Invalid date";
        }

        if (month < 1 || month > 12) {
            return "Invalid date";
        }

        int maxDay = 31;
        if (month == 4 || month == 6 || month == 9 || month == 11) {
            maxDay = 30;
        } else if (month == 2) {
            if (year % 4 == 0 && (year % 100 != 0 || year % 400 == 0)) {
                maxDay = 29;
            } else {
                maxDay = 28;
            }
        }

        if (day < 1 || day > maxDay || day == 31 && month == 12 && year == 2212) {
            return "Invalid date";
        }

        // Calculate next date
        if (day == maxDay && month == 12) {
            return "1/1/" + (year + 1);
        } else if (day == maxDay) {
            return "1/" + (month + 1) + "/" + year;
        } else {
            return (day + 1) + "/" + month + "/" + year;
        }
    }
}

